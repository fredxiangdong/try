package com.fred.poi.service;

public interface ImportExcelService {

	/**
	 * ����Excel����
	 * @param filePath
	 */
	public void importExcel(String filePath);
}
