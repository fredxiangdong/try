package com.fred.stock.service;


public interface RetriveStockDataService {
	
	public void retriveData();

}