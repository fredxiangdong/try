package com.fred.trying.service;

import com.fred.trying.entity.TbUser;

public interface UserService {

	public TbUser retrive(String username,String password);
	
	public void save(TbUser user);
}
