package com.fred.patten.w_command_pattern;

public class Receiver {

	public void action(){
		System.out.println("ִ������");
	}
}
