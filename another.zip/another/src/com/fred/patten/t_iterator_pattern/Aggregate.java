package com.fred.patten.t_iterator_pattern;

public interface Aggregate {

	public Iterator createIterator();
}
