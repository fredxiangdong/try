package com.fred.patten.b_strategypattern;

public abstract class CashSuper {

	public abstract Double acceptCash(Double money);
	
}
