package com.fred.patten.r_memo_pattern;

public class Caretaker {

	private Memo memo;

	public Memo getMemo() {
		return memo;
	}

	public void setMemo(Memo memo) {
		this.memo = memo;
	}
	
}
