package com.fred.patten.r_memo_pattern;

public class Memo {

	private String state;
	
	public Memo(String state){
		this.state = state;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}
	
}
