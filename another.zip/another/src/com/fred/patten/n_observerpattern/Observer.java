package com.fred.patten.n_observerpattern;

public interface Observer {

	public void update();
	
}
