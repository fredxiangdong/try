package com.fred.patten.p_state_pattern;

public abstract class State {

	public abstract void writeProgram(Work w);
}
