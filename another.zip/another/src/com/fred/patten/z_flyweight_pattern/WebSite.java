package com.fred.patten.z_flyweight_pattern;

public abstract class WebSite {

	public abstract void Use(User user);
}
