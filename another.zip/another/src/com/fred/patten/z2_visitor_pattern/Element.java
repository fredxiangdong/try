package com.fred.patten.z2_visitor_pattern;

public abstract class Element {

	public abstract void Accept(Visitor visitor);
}
