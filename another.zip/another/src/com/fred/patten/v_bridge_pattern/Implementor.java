package com.fred.patten.v_bridge_pattern;

public abstract class Implementor {

	public abstract void Operation();
}
