package com.fred.patten.g_proxy_pattern;

public interface GiveGift {

	public void GiveDolls();
	
	public void GiveFlowers();
	
	public void GiveChocolate();
}
