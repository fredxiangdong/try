package com.fred.patten.o_abstract_factory;

public interface IDepartment {

	public void insert(Department department);
	
	public Department getDepartment(int id);
}
