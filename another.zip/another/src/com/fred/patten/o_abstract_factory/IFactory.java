package com.fred.patten.o_abstract_factory;

public interface IFactory {

	public IDepartment createDepartment();
}
