package com.fred.patten.y_mediator_pattern;

public abstract class UnitedNations {

	public abstract void Declare(String message, Country colleague);
}
