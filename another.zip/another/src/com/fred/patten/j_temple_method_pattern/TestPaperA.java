package com.fred.patten.j_temple_method_pattern;

public class TestPaperA extends TestPaper{

	@Override
	public String Answer1() {
		return "b";
	}

	@Override
	public String Answer2() {
		return "c";
	}

}
