package com.fred.patten.j_temple_method_pattern;

public class TestPaperB extends TestPaper{

	@Override
	public String Answer1() {
		return "a";
	}

	@Override
	public String Answer2() {
		return "c";
	}

}
