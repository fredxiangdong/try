package com.fred.patten.h_factory_pattern;

public class Volunteer extends Leifeng{

}
