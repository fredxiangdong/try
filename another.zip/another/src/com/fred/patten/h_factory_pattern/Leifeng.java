package com.fred.patten.h_factory_pattern;

public class Leifeng {

	public void sweep(){
		System.out.println("ɨ��");
	}
	
	public void wash(){
		System.out.println("ϴ�·�");
	}
	
	public void buyRice(){
		System.out.println("����");
	}
	
}
