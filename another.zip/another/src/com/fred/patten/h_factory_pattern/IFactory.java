package com.fred.patten.h_factory_pattern;

public abstract class IFactory {

	public abstract Leifeng createLeifeng();
}
