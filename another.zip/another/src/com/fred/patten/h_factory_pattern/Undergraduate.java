package com.fred.patten.h_factory_pattern;

public class Undergraduate extends Leifeng{

}
