package com.fred.patten.l_apperancepatten;

public class ApparencePatternTest {

	public static void main(String[] args){
		Fecade fecade = new Fecade();
		fecade.methodA();
		fecade.methodB();
	}
}
