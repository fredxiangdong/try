package com.fred.patten.l_apperancepatten;

public class SubSystemOne {

	public void methodOne(){
		System.out.println("��ϵͳ����һ");
	}
}
