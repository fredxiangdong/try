package com.fred.patten.f_decoratepattern;

public class BigTrouser extends Finery{

	@Override
	public void show(){
		System.out.println("���");
		super.show();
	}
}
