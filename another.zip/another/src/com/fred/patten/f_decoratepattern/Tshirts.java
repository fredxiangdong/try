package com.fred.patten.f_decoratepattern;

public class Tshirts extends Finery{

	@Override
	public void show(){
		System.out.println("��T��");
		super.show();
	}
}
