package com.fred.patten.f_decoratepattern;

public class Sneaker extends Finery{

	@Override
	public void show(){
		System.out.println("����Ь");
		super.show();
	}
}
