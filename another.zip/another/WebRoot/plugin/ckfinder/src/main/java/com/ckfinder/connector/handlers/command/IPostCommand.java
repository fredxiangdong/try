package com.ckfinder.connector.handlers.command;

public interface IPostCommand {
}
